/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.*;
import java.util.*;

/**
 *
 * @author joche
 */
public class Dao_Cliente {
   
    private PreparedStatement ps;
    private ResultSet rs;
    private Cliente cl;
    Conexion c= new Conexion();
    private Connection con() throws SQLException,ClassNotFoundException{
       Class.forName(c.getDriver());
       return DriverManager.getConnection(c.getUrl(),c.getUser(),c.getPassword());
              
    }
    public ArrayList<Cliente> mostrar(){
        ArrayList<Cliente> ar=new ArrayList<Cliente>();
        try {
            ps=con().prepareStatement("select * from cliente");
            rs=ps.executeQuery();
            while(rs.next()){
              cl=new Cliente(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
              ar.add(cl);
                
            }
            
            
        } catch (Exception e) {
        }
            
        return ar;
    }
    public int insertar(Cliente cl){
        int n=0;
        try {
            ps=con().prepareStatement("insert into cliente( nombre,dui,nit,tel,correo,direccion) value(?,?,?,?,?,?)");
            ps.setString(1, cl.getNombre());
            ps.setString(2, cl.getDui());
            ps.setString(3, cl.getNit());
            ps.setString(4, cl.getTel());
            ps.setString(5, cl.getCorreo());
            ps.setString(6, cl.getDireccion());
            n=ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return n;
    }
    public int Modificar(Cliente cl){
        int n=0;
        try {
            ps=con().prepareStatement("update  cliente set nombre=?,dui=?,nit=?,tel=?,correo=?,direccion=? where idCliente=?");
            
            ps.setString(1, cl.getNombre());
            ps.setString(2, cl.getDui());
            ps.setString(3, cl.getDui());
            ps.setString(4, cl.getDui());
            ps.setString(5, cl.getDui());
            ps.setString(6, cl.getDui());
            ps.setInt(7, cl.getIdCliente());
            n=ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return n;
    }
    public int eliminar(Cliente cl){
        int n=0;
        try {
            ps=con().prepareStatement("delete from cliente where idCliente=?");
            ps.setInt(1, cl.getIdCliente());
            n=ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return n;
    }
}
